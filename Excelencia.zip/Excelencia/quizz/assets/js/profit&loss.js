const quizData = [
    {
        question: "A shopkeeper sells an article for $200 at a profit of 25%. What was the cost price of the article?",
        a: "$160",
        b: "$150",
        c: "$175",
        d: "$180",
        correct: "a"
    },
    {
        question: "A trader bought a bicycle for $600 and sold it for $750. What is the profit percentage?",
        a: "20%",
        b: "25%",
        c: "30%",
        d: "35%",
        correct: "b"
    },
    {
        question: "If an article is sold at a loss of 20% and the selling price is $240, what is the cost price?",
        a: "$300",
        b: "$290",
        c: "$280",
        d: "$250",
        correct: "a"
    },
    {
        question: "A man bought 50 items at $10 each and sold them at a profit of 30%. What is the selling price per item?",
        a: "$13",
        b: "$14",
        c: "$15",
        d: "$16",
        correct: "a"
    },
    {
        question: "If an article is sold for $450, resulting in a profit of 12.5%, what is the cost price?",
        a: "$400",
        b: "$420",
        c: "$440",
        d: "$430",
        correct: "a"
    },
    {
        question: "A merchant sells an article at a profit of 20%. If the cost price is $500, what is the selling price?",
        a: "$600",
        b: "$550",
        c: "$525",
        d: "$575",
        correct: "b"
    },
    {
        question: "A book is sold for $320 at a loss of 20%. What was the cost price?",
        a: "$400",
        b: "$350",
        c: "$360",
        d: "$370",
        correct: "a"
    },
    {
        question: "A trader marks his goods 25% above the cost price and allows a discount of 10%. What is his gain percentage?",
        a: "12.5%",
        b: "13.5%",
        c: "15%",
        d: "10%",
        correct: "a"
    },
    {
        question: "If the cost price of 20 articles is equal to the selling price of 15 articles, what is the profit percentage?",
        a: "33.33%",
        b: "25%",
        c: "20%",
        d: "10%",
        correct: "a"
    },
    {
        question: "A man sold two articles for $200 each. On one, he gained 20% and on the other, he lost 20%. What is his overall gain or loss percentage?",
        a: "2% loss",
        b: "2% gain",
        c: "4% loss",
        d: "No gain, no loss",
        correct: "c"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
