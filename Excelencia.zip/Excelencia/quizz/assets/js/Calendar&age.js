const quizData = [
    {
        question: "If today is Monday, what will be the day after 61 days?",
        a: "Wednesday",
        b: "Thursday",
        c: "Friday",
        d: "Saturday",
        correct: "b"
    },
    {
        question: "Find the day of the week on 15th August 1947.",
        a: "Monday",
        b: "Tuesday",
        c: "Friday",
        d: "Saturday",
        correct: "c"
    },
    {
        question: "A person was born on 29th February 2000. How many birthdays will he have celebrated by 29th February 2020?",
        a: "4",
        b: "5",
        c: "6",
        d: "7",
        correct: "a"
    },
    {
        question: "If the 5th of a month is a Monday, what day of the week will the 31st of the same month be?",
        a: "Wednesday",
        b: "Thursday",
        c: "Friday",
        d: "Saturday",
        correct: "a"
    },
    {
        question: "What was the day of the week on 1st January 2001?",
        a: "Monday",
        b: "Tuesday",
        c: "Sunday",
        d: "Wednesday",
        correct: "a"
    },
    {
        question: "If 2004 was a leap year, which of the following years will also be a leap year?",
        a: "2008",
        b: "2009",
        c: "2010",
        d: "2012",
        correct: "a"
    },
    {
        question: "A father is twice as old as his son. Twenty years ago, the father was 12 times as old as his son. How old is the son now?",
        a: "22",
        b: "24",
        c: "26",
        d: "28",
        correct: "b"
    },
    {
        question: "A mother is three times as old as her daughter. After 12 years, she will be twice as old as her daughter. What is the daughter's current age?",
        a: "6",
        b: "8",
        c: "10",
        d: "12",
        correct: "c"
    },
    {
        question: "The sum of the ages of a father and son is 45 years. Five years ago, the father's age was four times the age of his son. What are their present ages?",
        a: "35 and 10",
        b: "36 and 9",
        c: "30 and 15",
        d: "33 and 12",
        correct: "a"
    },
    {
        question: "In a family, the father is 5 years older than the mother and the mother is 4 times as old as their daughter. If the daughter is 5 years old, how old is the father?",
        a: "40",
        b: "45",
        c: "50",
        d: "55",
        correct: "b"
    }
];


const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
