const quizData = [
    {
        question: "What is the simple interest on $1000 for 3 years at an annual interest rate of 5%?",
        a: "$150",
        b: "$200",
        c: "$250",
        d: "$300",
        correct: "a"
    },
    {
        question: "If the simple interest on a sum of money for 2 years is $120 at an annual interest rate of 6%, what is the principal amount?",
        a: "$800",
        b: "$1000",
        c: "$1200",
        d: "$1500",
        correct: "b"
    },
    {
        question: "A sum of money amounts to $660 in 2 years at an annual interest rate of 10%. What is the principal amount?",
        a: "$500",
        b: "$550",
        c: "$600",
        d: "$650",
        correct: "c"
    },
    {
        question: "What is the annual interest rate if a sum of money doubles itself in 10 years at simple interest?",
        a: "5%",
        b: "8%",
        c: "10%",
        d: "12%",
        correct: "a"
    },
    {
        question: "If the simple interest on a sum of money is $180 for 3 years at an annual interest rate of 4%, what is the principal amount?",
        a: "$1200",
        b: "$1500",
        c: "$1800",
        d: "$2000",
        correct: "b"
    },
    {
        question: "A sum of $2000 is lent out at simple interest for 3 years at an annual interest rate of 5%. What is the total amount to be paid back?",
        a: "$2100",
        b: "$2200",
        c: "$2300",
        d: "$2300",
        correct: "c"
    },
    {
        question: "How long will it take for $1500 to earn $450 in simple interest at an annual interest rate of 6%?",
        a: "3 years",
        b: "4 years",
        c: "5 years",
        d: "6 years",
        correct: "c"
    },
    {
        question: "If a sum of money is invested at an annual interest rate of 8% and earns $320 in 4 years, what is the principal amount?",
        a: "$800",
        b: "$900",
        c: "$1000",
        d: "$1200",
        correct: "c"
    },
    {
        question: "A person borrows $2500 at an annual interest rate of 7% for 4 years. What is the total interest to be paid?",
        a: "$600",
        b: "$700",
        c: "$800",
        d: "$900",
        correct: "b"
    },
    {
        question: "What is the simple interest on $1500 for 5 years at an annual interest rate of 6%?",
        a: "$350",
        b: "$400",
        c: "$450",
        d: "$500",
        correct: "d"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
