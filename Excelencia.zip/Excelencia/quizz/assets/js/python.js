const quizData = [
    {
        question: "What is the output of print(str[0]) if str = 'Hello'?",
        a: "H",
        b: "e",
        c: "o",
        d: "None of the above",
        correct: "a"
    },
    {
        question: "How do you insert COMMENTS in Python code?",
        a: "// This is a comment",
        b: "/* This is a comment */",
        c: "# This is a comment",
        d: "-- This is a comment",
        correct: "c"
    },
    {
        question: "Which operator is used to multiply numbers in Python?",
        a: "x",
        b: "*",
        c: "^",
        d: "%",
        correct: "b"
    },
    {
        question: "Which keyword is used to create a function in Python?",
        a: "function",
        b: "def",
        c: "fun",
        d: "define",
        correct: "b"
    },
    {
        question: "What is the correct syntax to output the type of a variable or object in Python?",
        a: "print(typeof x)",
        b: "print(typeOf(x))",
        c: "print(type(x))",
        d: "print(typeof(x))",
        correct: "c"
    },
    {
        question: "What is the correct file extension for Python files?",
        a: ".pt",
        b: ".pyth",
        c: ".py",
        d: ".pyt",
        correct: "c"
    },
    {
        question: "Which method can be used to remove any whitespace from both the beginning and the end of a string?",
        a: "strip()",
        b: "trim()",
        c: "len()",
        d: "strim()",
        correct: "a"
    },
    {
        question: "Which of the following is the correct syntax for a conditional expression in Python?",
        a: "if (x > y) { }",
        b: "if x > y:",
        c: "if x > y then",
        d: "if x > y {}",
        correct: "b"
    },
    {
        question: "Which of the following is used to define a block of code in Python?",
        a: "Curly braces {}",
        b: "Square brackets []",
        c: "Indentation",
        d: "Parentheses ()",
        correct: "c"
    },
    {
        question: "How do you start a for loop in Python?",
        a: "for x in y:",
        b: "for x in y {}",
        c: "for each x in y:",
        d: "for x to y:",
        correct: "a"
    }
];
const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href = 'firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
