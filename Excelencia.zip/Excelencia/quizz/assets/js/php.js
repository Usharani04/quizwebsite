const quizData = [
    {
        question: "What does PHP stand for?",
        a: "Personal Home Page",
        b: "PHP: Hypertext Preprocessor",
        c: "Private Hypertext Processor",
        d: "Pretext Hypertext Processor",
        correct: "b"
    },
    {
        question: "Which superglobal variable is used to retrieve form data after submitting an HTML form?",
        a: "$_GET",
        b: "$_POST",
        c: "$_REQUEST",
        d: "$_SERVER",
        correct: "b"
    },
    {
        question: "How do you start a session in PHP?",
        a: "session_start()",
        b: "start_session()",
        c: "begin_session()",
        d: "new_session()",
        correct: "a"
    },
    {
        question: "Which function is used to check if a variable is an array in PHP?",
        a: "is_array()",
        b: "array_check()",
        c: "check_array()",
        d: "isArray()",
        correct: "a"
    },
    {
        question: "What is the correct way to add comments in PHP?",
        a: "// This is a comment",
        b: "<!-- This is a comment -->",
        c: "/* This is a comment */",
        d: "# This is a comment",
        correct: "c"
    },
    {
        question: "How do you include a PHP file named 'header.php'?",
        a: "include 'header.php';",
        b: "include_file 'header.php';",
        c: "require 'header.php';",
        d: "require_once 'header.php';",
        correct: "d"
    },
    {
        question: "What is the correct way to start a PHP block?",
        a: "<?php",
        b: "<script>",
        c: "<?script>",
        d: "<?php echo 'Hello World'; ?>",
        correct: "a"
    },
    {
        question: "How can you redirect the user to another page in PHP?",
        a: "redirect('newpage.php');",
        b: "header('Location: newpage.php');",
        c: "go('newpage.php');",
        d: "move_to('newpage.php');",
        correct: "b"
    },
    {
        question: "Which function is used to count the number of elements in an array in PHP?",
        a: "array_length()",
        b: "length()",
        c: "count()",
        d: "size()",
        correct: "c"
    },
    {
        question: "What is the default method for sending form data in PHP?",
        a: "GET",
        b: "POST",
        c: "PUT",
        d: "REQUEST",
        correct: "a"
    }
];


const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `; 
    } else {
        alert("Please select an answer before submitting.");
    }
});
