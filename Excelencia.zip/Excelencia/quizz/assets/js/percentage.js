const quizData = [
    {
        question: "What is 25% of 200?",
        a: "50",
        b: "40",
        c: "60",
        d: "30",
        correct: "a"
    },
    {
        question: "A product originally priced at $150 is discounted by 20%. What is the sale price?",
        a: "$110",
        b: "$120",
        c: "$130",
        d: "$140",
        correct: "b"
    },
    {
        question: "If 75% of a number is 300, what is the number?",
        a: "350",
        b: "400",
        c: "450",
        d: "500",
        correct: "d"
    },
    {
        question: "A salary increased from $2000 to $2500. What is the percentage increase?",
        a: "20%",
        b: "25%",
        c: "30%",
        d: "35%",
        correct: "b"
    },
    {
        question: "A population of 5000 decreased by 10% over a year. What is the population at the end of the year?",
        a: "4500",
        b: "4600",
        c: "4700",
        d: "4800",
        correct: "d"
    },
    {
        question: "A student scored 72 out of 90 on a test. What percentage did the student score?",
        a: "75%",
        b: "80%",
        c: "85%",
        d: "90%",
        correct: "b"
    },
    {
        question: "If the price of an item increases from $50 to $60, what is the percentage increase?",
        a: "15%",
        b: "20%",
        c: "25%",
        d: "30%",
        correct: "b"
    },
    {
        question: "40% of a number is 80. What is the number?",
        a: "180",
        b: "190",
        c: "200",
        d: "210",
        correct: "c"
    },
    {
        question: "A man spends 60% of his income and saves the rest. If his income is $2500, how much does he save?",
        a: "$1000",
        b: "$900",
        c: "$800",
        d: "$700",
        correct: "a"
    },
    {
        question: "The price of a laptop is increased by 15% to $690. What was the original price?",
        a: "$600",
        b: "$580",
        c: "$550",
        d: "$500",
        correct: "a"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
