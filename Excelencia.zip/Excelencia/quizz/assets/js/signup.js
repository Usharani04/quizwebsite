document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('signupForm')?.addEventListener('submit', function(e) {
        e.preventDefault();

        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        const confirmPassword = this.querySelector('input[type="password"]:nth-of-type(2)').value;

        if (email === 'usharani@gmail.com' && password === 'usha' && password === confirmPassword) {
            alert('Registration successful!');
            window.location.href = 'firstpage.html'; // Redirect to firstpage.html on successful registration
        } else {
            alert('Registration not successful! Please check your details.');
        }
    });
});