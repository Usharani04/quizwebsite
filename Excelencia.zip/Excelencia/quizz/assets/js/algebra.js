const quizData = [
    {
        question: "Solve for x: 2x + 3 = 11",
        a: "4",
        b: "5",
        c: "3",
        d: "6",
        correct: "a"
    },
    {
        question: "What is the solution to the equation: 3x - 4 = 5x + 8?",
        a: "-6",
        b: "6",
        c: "-12",
        d: "12",
        correct: "a"
    },
    {
        question: "If y = 2x + 5 and y = 3x - 4, what is the value of x?",
        a: "7",
        b: "9",
        c: "6",
        d: "8",
        correct: "a"
    },
    {
        question: "Simplify: (2x^2 + 3x - 5) - (x^2 - 4x + 2)",
        a: "x^2 + 7x - 7",
        b: "x^2 + 7x - 3",
        c: "x^2 + 7x - 5",
        d: "x^2 + 7x + 7",
        correct: "a"
    },
    {
        question: "Solve for x: x^2 - 5x + 6 = 0",
        a: "2, 3",
        b: "1, 6",
        c: "-2, -3",
        d: "2, -3",
        correct: "a"
    },
    {
        question: "If f(x) = 2x^2 - 3x + 1, what is f(2)?",
        a: "3",
        b: "5",
        c: "7",
        d: "9",
        correct: "b"
    },
    {
        question: "Simplify: (3x^3 * 2x^2) / (6x)",
        a: "x^4",
        b: "x^3",
        c: "x^2",
        d: "2x^2",
        correct: "a"
    },
    {
        question: "Solve for x: 5x + 4 = 2x + 10",
        a: "3",
        b: "2",
        c: "1",
        d: "4",
        correct: "b"
    },
    {
        question: "What is the value of x in the equation: 4x^2 = 64?",
        a: "8",
        b: "4",
        c: "2",
        d: "6",
        correct: "b"
    },
    {
        question: "Simplify: (x^2 - 9) / (x - 3)",
        a: "x + 3",
        b: "x - 3",
        c: "x^2 + 3",
        d: "x + 2",
        correct: "a"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
           <button onclick="window.location.href = 'firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
