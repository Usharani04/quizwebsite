const quizData = [
    {
        question: "Which of the following is the correct syntax to declare a pointer?",
        a: "int ptr;",
        b: "int *ptr;",
        c: "int &ptr;",
        d: "ptr int;",
        correct: "b"
    },
    {
        question: "Which of the following is used to define a constant in C++?",
        a: "#define",
        b: "const",
        c: "static",
        d: "final",
        correct: "b"
    },
    {
        question: "Which operator is used to access the member function of a class using a pointer?",
        a: ".",
        b: "->",
        c: "::",
        d: "*",
        correct: "b"
    },
    {
        question: "What is the size of a pointer on a 64-bit machine?",
        a: "4 bytes",
        b: "8 bytes",
        c: "16 bytes",
        d: "32 bytes",
        correct: "b"
    },
    {
        question: "Which of the following is the correct syntax to read a string using cin?",
        a: "cin >> str;",
        b: "cin.get(str);",
        c: "cin.str();",
        d: "get(str);",
        correct: "a"
    },
    {
        question: "Which of the following is not a valid access specifier in C++?",
        a: "public",
        b: "protected",
        c: "private",
        d: "global",
        correct: "d"
    },
    {
        question: "Which of the following correctly declares an array in C++?",
        a: "int array[10];",
        b: "int array;",
        c: "array{10};",
        d: "array array[10];",
        correct: "a"
    },
    {
        question: "Which of the following is used to terminate a loop?",
        a: "continue",
        b: "terminate",
        c: "break",
        d: "exit",
        correct: "c"
    },
    {
        question: "What is the correct way to declare a friend function?",
        a: "friend void func();",
        b: "void friend func();",
        c: "friend func();",
        d: "func friend();",
        correct: "a"
    },
    {
        question: "Which of the following is the correct syntax for inheritance in C++?",
        a: "class Derived : public Base {}",
        b: "class Derived extends Base {}",
        c: "class Derived inherits Base {}",
        d: "class Derived : Base {}",
        correct: "a"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';>Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
