const quizData = [
    {
        question: "Choose the word that is most nearly opposite in meaning to the word 'ACCEPT':",
        a: "Receive",
        b: "Decline",
        c: "Include",
        d: "Permit",
        correct: "b"
    },
    {
        question: "Choose the correct word to complete the sentence: She is known for her ability to ______ complex ideas clearly and concisely.",
        a: "Expound",
        b: "Confound",
        c: "Revoke",
        d: "Distort",
        correct: "a"
    },
    {
        question: "Which of the following sentences is grammatically correct?",
        a: "Neither the manager nor the employees was happy with the changes.",
        b: "Neither the manager nor the employees were happy with the changes.",
        c: "Neither the manager nor the employees is happy with the changes.",
        d: "Neither the manager nor the employees are happy with the changes.",
        correct: "b"
    },
    {
        question: "Choose the best word to complete the analogy: PEN is to WRITE as SCISSORS is to ______.",
        a: "Cut",
        b: "Draw",
        c: "Glue",
        d: "Sew",
        correct: "a"
    },
    {
        question: "Select the option that best expresses the meaning of the idiom: 'Burning the midnight oil'.",
        a: "Working late into the night",
        b: "Being wasteful",
        c: "Using an old-fashioned method",
        d: "Celebrating a special occasion",
        correct: "a"
    },
    {
        question: "What is the meaning of the word 'UBIQUITOUS'?",
        a: "Rare and precious",
        b: "Existing everywhere",
        c: "Extremely dangerous",
        d: "Very expensive",
        correct: "b"
    },
    {
        question: "Fill in the blank: The scientist was able to ______ the results of his experiments in a detailed report.",
        a: "Invalidate",
        b: "Explicate",
        c: "Obfuscate",
        d: "Eliminate",
        correct: "b"
    },
    {
        question: "Choose the correct word to complete the sentence: The CEO's speech was filled with ______ to motivate the employees.",
        a: "Apathy",
        b: "Motifs",
        c: "Platitudes",
        d: "Dissensions",
        correct: "c"
    },
    {
        question: "Identify the type of error in the sentence: 'She enjoys to read books in her spare time.'",
        a: "Tense error",
        b: "Pronoun error",
        c: "Verb form error",
        d: "Article error",
        correct: "c"
    },
    {
        question: "What does the word 'CONFLUENCE' mean?",
        a: "A separation or divergence",
        b: "A coming together or merging",
        c: "A state of confusion",
        d: "A feeling of nostalgia",
        correct: "b"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
