const quizData = [
    {
        question: "Which of the following is a correct syntax to declare a pointer?",
        a: "int *ptr;",
        b: "int ptr;",
        c: "ptr *int;",
        d: "pointer ptr;",
        correct: "a"
    },
    {
        question: "What is the result of the expression: 10 % 3?",
        a: "3",
        b: "1",
        c: "0",
        d: "10",
        correct: "b"
    },
    {
        question: "Which of the following is not a storage class in C?",
        a: "auto",
        b: "register",
        c: "volatile",
        d: "extern",
        correct: "c"  
    },
    {
        question: "Which of the following functions is used to find the first occurrence of a character in a string in C?",
        a: "strcpy",
        b: "strcat",
        c: "strchr",
        d: "strlen",
        correct: "c"
    },
    {
        question: "What is the correct syntax to dynamically allocate memory in C?",
        a: "int *ptr = malloc(sizeof(int));",
        b: "int ptr = malloc(int);",
        c: "ptr malloc(sizeof(int));",
        d: "malloc ptr = int(sizeof);",
        correct: "a"
    },
    {
        question: "Which function is used to compare two strings in C?",
        a: "strcmp()",
        b: "strcompare()",
        c: "string_compare()",
        d: "compare()",
        correct: "a"
    },
    {
        "question": "Which of the following is not a valid keyword in C?",
         a: "goto",
         b: "struct",
         c: "class",
         d: "union",
         correct: "c"
    },
    {
        question: "Which of the following is not a valid data type in C?",
        a: "long",
        b: "float",
        c: "real",
        d: "double",
        correct: "c"
    },
    {
       question: "Which of the following operators cannot be overloaded in C?",
       a: "+",
       b: "++",
       c: "[]",
       d: "::",
       correct: "d"
    },
    {
        question: "Which loop is used to execute a block of code repeatedly as long as a condition is true?",
        a: "for loop",
        b: "while loop",
        c: "do-while loop",
        d: "switch loop",
        correct: "b"
    }
];


const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href = 'firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
