const quizData = [
    {
        question: "A bag contains 4 red balls, 5 blue balls, and 6 green balls. What is the probability of drawing a red ball?",
        a: "1/3",
        b: "2/5",
        c: "4/15",
        d: "1/5",
        correct: "c"
    },
    {
        question: "What is the probability of rolling a sum of 7 with two six-sided dice?",
        a: "1/6",
        b: "1/8",
        c: "1/9",
        d: "1/12",
        correct: "a"
    },
    {
        question: "A card is drawn from a standard deck of 52 cards. What is the probability of drawing a King or a Queen?",
        a: "1/13",
        b: "2/13",
        c: "1/26",
        d: "1/52",
        correct: "b"
    },
    {
        question: "A box contains 3 black, 4 white, and 5 red balls. If one ball is drawn at random, what is the probability that it is neither black nor white?",
        a: "1/3",
        b: "1/4",
        c: "1/2",
        d: "1/6",
        correct: "a"
    },
    {
        question: "If two coins are tossed, what is the probability of getting at least one head?",
        a: "1/4",
        b: "1/3",
        c: "2/3",
        d: "3/4",
        correct: "d"
    },
    {
        question: "What is the probability of drawing a heart from a standard deck of 52 cards?",
        a: "1/2",
        b: "1/3",
        c: "1/4",
        d: "1/5",
        correct: "c"
    },
    {
        question: "A bag contains 5 blue and 7 red balls. Two balls are drawn at random. What is the probability that both are red?",
        a: "1/11",
        b: "5/33",
        c: "7/22",
        d: "2/11",
        correct: "b"
    },
    {
        question: "What is the probability of getting an odd number when a die is rolled?",
        a: "1/2",
        b: "1/3",
        c: "1/4",
        d: "1/6",
        correct: "a"
    },
    {
        question: "In a class of 30 students, 18 are girls and the rest are boys. A student is chosen at random. What is the probability of choosing a boy?",
        a: "1/2",
        b: "2/5",
        c: "1/3",
        d: "3/5",
        correct: "c"
    },
    {
        question: "A jar contains 3 red, 5 green, and 2 blue marbles. If one marble is drawn at random, what is the probability that it is either green or blue?",
        a: "2/5",
        b: "7/10",
        c: "1/2",
        d: "3/5",
        correct: "b"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
