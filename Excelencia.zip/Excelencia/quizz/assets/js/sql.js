const quizData = [
    {
        question: "Which SQL keyword is used to retrieve a unique set of rows from a table?",
        a: "UNIQUE",
        b: "DISTINCT",
        c: "DIFFERENT",
        d: "SINGULAR",
        correct: "b"
    },
    {
        question: "What is the purpose of the SQL GROUP BY clause?",
        a: "To sort the result-set in ascending or descending order",
        b: "To restrict the number of rows in the result-set",
        c: "To apply aggregate functions to grouped rows",
        d: "To filter rows based on a condition",
        correct: "c"
    },
    {
        question: "Which SQL statement is used to delete data from a database?",
        a: "REMOVE FROM",
        b: "DELETE FROM",
        c: "ERASE FROM",
        d: "DROP FROM",
        correct: "b"
    },
    {
        question: "In SQL, which operator is used to compare values in a WHERE clause if you are interested in a range?",
        a: "LIKE",
        b: "BETWEEN",
        c: "IN",
        d: "COMPARE",
        correct: "b"
    },
    {
        question: "What does the SQL keyword 'HAVING' do?",
        a: "It filters rows based on a condition after the GROUP BY clause",
        b: "It specifies the order of rows in the result set",
        c: "It joins multiple tables based on a related column between them",
        d: "It adds new columns to a table",
        correct: "a"
    },
    {
        question: "Which SQL statement is used to add new rows of data to a table?",
        a: "ADD NEW",
        b: "INSERT INTO",
        c: "ADD INTO",
        d: "ADD ROW",
        correct: "b"
    },
    {
        question: "What is the purpose of the SQL ORDER BY clause?",
        a: "To specify which columns to include in the result set",
        b: "To group rows that have the same value into summary rows",
        c: "To sort the result set based on one or more columns",
        d: "To restrict the number of rows returned by a query",
        correct: "c"
    },
    {
        question: "Which SQL function is used to count the number of rows in a table?",
        a: "COUNT()",
        b: "SUM()",
        c: "MAX()",
        d: "AVERAGE()",
        correct: "a"
    },
    {
        question: "In SQL, which JOIN returns all rows when there is at least one match in both tables?",
        a: "INNER JOIN",
        b: "OUTER JOIN",
        c: "LEFT JOIN",
        d: "FULL JOIN",
        correct: "b"
    },
    {
        question: "What does the SQL keyword 'AS' do?",
        a: "It is used to specify a condition in a WHERE clause",
        b: "It renames a column or table with an alias",
        c: "It sorts the result set in ascending or descending order",
        d: "It filters rows based on a condition after the GROUP BY clause",
        correct: "b"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
