const quizData = [
    {
        question: "What is the correct syntax for main method in Java?",
        a: "public void main(String[] args)",
        b: "public static void main(String[] args)",
        c: "public static int main(String[] args)",
        d: "public void static main(String[] args)",
        correct: "b"
    },
    {
        question: "Which data type is used to create a variable that should store text?",
        a: "String",
        b: "int",
        c: "float",
        d: "char",
        correct: "a"
    },
    {
        question: "How do you create a variable with the numeric value 5?",
        a: "int x = 5;",
        b: "num x = 5;",
        c: "float x = 5;",
        d: "x = 5;",
        correct: "a"
    },
    {
        question: "Which method can be used to find the length of a string?",
        a: "length()",
        b: "getLength()",
        c: "len()",
        d: "getSize()",
        correct: "a"
    },
    {
        question: "Which keyword is used to create a class in Java?",
        a: "class",
        b: "Class",
        c: "myClass",
        d: "newClass",
        correct: "a"
    },
    {
        question: "Which operator is used to compare two values?",
        a: "==",
        b: "=",
        c: "===",
        d: "!=",
        correct: "a"
    },
    {
        question: "Which statement is used to stop a loop?",
        a: "break",
        b: "stop",
        c: "exit",
        d: "return",
        correct: "a"
    },
    {
        question: "How do you start writing an if statement in Java?",
        a: "if x > y then",
        b: "if (x > y)",
        c: "if x > y",
        d: "if {x > y}",
        correct: "b"
    },
    {
        question: "Which keyword is used to import a package in Java?",
        a: "import",
        b: "Import",
        c: "include",
        d: "Include",
        correct: "a"
    },
    {
        question: "How do you create a method in Java?",
        a: "methodName()",
        b: "createMethod()",
        c: "method methodName()",
        d: "void methodName()",
        correct: "d"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
