document.addEventListener('DOMContentLoaded', () => {
    const formContainer = document.querySelector('.form_container');

    document.getElementById('loginForm')?.addEventListener('submit', function(e) {
        e.preventDefault();

        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;

        if (email === 'usharani@gmail.com' && password === 'usha') {
            alert('Login successful!');
            window.location.href = 'firstpage.html'; // Replace with your desired URL
        } else {
            alert('Invalid email or password');
        }
    });    
});
