const quizData = [
    {
        question: "What is the correct way to declare a JavaScript variable?",
        a: "variable carName;",
        b: "var carName;",
        c: "v carName;",
        d: "declare carName;",
        correct: "b"
    },
    {
        question: "Which built-in method calls a function for each element in the array?",
        a: "while()",
        b: "loop()",
        c: "forEach()",
        d: "each()",
        correct: "c"
    },
    {
        question: "How can you add a comment in JavaScript?",
        a: "//This is a comment",
        b: "'This is a comment",
        c: "<!--This is a comment-->",
        d: "/*This is a comment*/",
        correct: "d"
    },
    {
        question: "Which operator is used to assign a value to a variable?",
        a: "*",
        b: "=",
        c: "==",
        d: ":=",
        correct: "b"
    },
    {
        question: "What will the following code output: console.log(typeof [])?",
        a: "object",
        b: "array",
        c: "undefined",
        d: "string",
        correct: "a"
    },
    {
        question: "Which function is used to parse a string to an integer?",
        a: "parseInt()",
        b: "stringToInt()",
        c: "parseInteger()",
        d: "intParse()",
        correct: "a"
    },
    {
        question: "What is a JavaScript callback function?",
        a: "A function that is called before the main function",
        b: "A function that is passed as an argument to another function",
        c: "A function that returns a value",
        d: "A function that is invoked immediately",
        correct: "b"
    },
    {
        question: "Which method is used to add new elements to the end of an array?",
        a: "push()",
        b: "append()",
        c: "addToEnd()",
        d: "attach()",
        correct: "a"
    },
    {
        question: "What is the output of: console.log('1' + 1)?",
        a: "2",
        b: "11",
        c: "1 + 1",
        d: "undefined",
        correct: "b"
    },
    {
        question: "Which statement is used to stop the execution of a JavaScript function and return a value?",
        a: "exit",
        b: "return",
        c: "stop",
        d: "end",
        correct: "b"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});
