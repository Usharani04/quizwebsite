let countdown = 5;
const timeSpan = document.getElementById('time-span');

function updateCountdown() {
    if (countdown > 0) {
        countdown--;
        timeSpan.textContent = countdown;
    } else {
        clearInterval(countdownInterval);
        window.location.href = 'java.html';  // Redirect to the target page
    }
}

const countdownInterval = setInterval(updateCountdown, 1000);

