const quizData = [
    {
        question: "If all roses are flowers and some flowers fade quickly, which of the following is true?",
        a: "All roses fade quickly",
        b: "Some roses fade quickly",
        c: "No roses fade quickly",
        d: "Some flowers do not fade quickly",
        correct: "d"
    },
    {
        question: "Choose the number that is different from the rest: 2, 3, 5, 7, 11, 13, 15",
        a: "3",
        b: "7",
        c: "11",
        d: "15",
        correct: "d"
    },
    {
        question: "If A is taller than B and B is taller than C, who is the tallest?",
        a: "A",
        b: "B",
        c: "C",
        d: "Cannot be determined",
        correct: "a"
    },
    {
        question: "Find the next number in the series: 1, 4, 9, 16, 25, __?",
        a: "35",
        b: "36",
        c: "49",
        d: "64",
        correct: "b"
    },
    {
        question: "Which of the following can be arranged into a 5-letter English word?",
        a: "H C I P A",
        b: "R E Q U A",
        c: "W Q R G S",
        d: "L O P M N",
        correct: "a"
    },
    {
        question: "If the code for CAT is 3120, and the code for DOG is 4157, what is the code for COG?",
        a: "3157",
        b: "3127",
        c: "3147",
        d: "3177",
        correct: "a"
    },
    {
        question: "In a family of six, B is the brother of C. A is the mother of B. D is the father of A. E is the daughter of D. F is the son of E. How is F related to C?",
        a: "Cousin",
        b: "Uncle",
        c: "Nephew",
        d: "Brother",
        correct: "a"
    },
    {
        question: "A man walks 10 meters east, then 5 meters south, then 15 meters west, and finally 10 meters north. How far is he from his starting point?",
        a: "5 meters",
        b: "10 meters",
        c: "15 meters",
        d: "20 meters",
        correct: "a"
    },
    {
        question: "If BEAR is written as YVZI, how would you write LION?",
        a: "OLMR",
        b: "ORNL",
        c: "OLRM",
        d: "OMRI",
        correct: "b"
    },
    {
        question: "A train travels 60 kilometers in the first hour, 90 kilometers in the second hour, and 120 kilometers in the third hour. What is the average speed of the train?",
        a: "80 km/h",
        b: "90 km/h",
        c: "100 km/h",
        d: "110 km/h",
        correct: "b"
    }
];

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const submitBtn = document.getElementById('submit');

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    prevBtn.style.display = currentQuiz > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = currentQuiz < quizData.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuiz === quizData.length - 1 ? 'inline-block' : 'none';
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer;

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id;
        }
    });

    return answer;
}

prevBtn.addEventListener('click', () => {
    currentQuiz--;
    loadQuiz();
});

nextBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;
        loadQuiz();
    } else {
        alert("Please select an answer before proceeding to the next question.");
    }
});

submitBtn.addEventListener('click', () => {
    const answer = getSelected();

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++;
        }

        quiz.innerHTML = `
            <h2>You answered ${score}/${quizData.length} questions correctly</h2>
            <button onclick="window.location.href='firstpage.html';">Back</button>
        `;
    } else {
        alert("Please select an answer before submitting.");
    }
});